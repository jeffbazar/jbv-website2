import Image from 'next/image';

export default function About() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <div className="relative w-full h-[40vh] md:h-[50vh]">
        <div className="absolute inset-0 bg-black/30 z-10"></div>
        <Image
          src="/about-bg.jpg"
          alt="About Background"
          fill
          priority
          className="object-cover"
        />
        <div className="absolute inset-0 z-20 flex items-center justify-center text-center px-4">
          <h1 className="text-6xl md:text-8xl font-serif text-white">ABOUT ME</h1>
        </div>
      </div>

      {/* Content Section */}
      <div className="container mx-auto px-4 py-12">
        <div className="flex flex-col md:flex-row gap-8">
          <div className="md:w-1/3">
            <Image
              src="/business-meeting.jpg"
              alt="Business Meeting"
              width={400}
              height={300}
              className="rounded-md"
            />
            <div className="mt-4">
              <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer" className="inline-block">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="#004494">
                  <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                </svg>
              </a>
            </div>
          </div>
          <div className="md:w-2/3">
            <h2 className="text-3xl md:text-4xl font-serif text-jbv-blue mb-6">This is the space to introduce the business and what it has to offer.</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
              <div>
                <p className="mb-4">
                  This is a space to share more about the business: who&apos;s behind it, what it does and what this site has to offer. It&apos;s an opportunity to tell the story behind the business or describe a special service or product it offers. You can use this section to share the company history or highlight a particular feature that sets it apart from competitors.
                </p>
              </div>
              <div>
                <p>
                  Let the writing speak for itself. Keep a consistent tone and voice throughout the website to stay true to the brand image and give visitors a taste of the company&apos;s values and personality.
                </p>
              </div>
            </div>

            {/* Certifications Section */}
            <div className="bg-gray-100 p-6 rounded-md mb-8">
              <h3 className="text-2xl font-serif text-jbv-blue mb-4">Certifications</h3>
              <hr className="border-gray-300 mb-4" />
              <ul className="list-disc pl-6 space-y-2">
                <li>Describe the certification.</li>
                <li>Describe the certification.</li>
                <li>Describe the certification.</li>
                <li>Describe the certification.</li>
              </ul>
            </div>

            {/* Qualifications Section */}
            <div className="bg-gray-100 p-6 rounded-md">
              <h3 className="text-2xl font-serif text-jbv-blue mb-4">Qualifications</h3>
              <hr className="border-gray-300 mb-4" />
              <ul className="list-disc pl-6 space-y-2">
                <li>Describe the qualification.</li>
                <li>Describe the qualification.</li>
                <li>Describe the qualification.</li>
                <li>Describe the qualification.</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
