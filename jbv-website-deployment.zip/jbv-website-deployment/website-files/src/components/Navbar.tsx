import Link from 'next/link';

export default function Navbar() {
  return (
    <nav className="w-full py-4 px-6 flex justify-between items-center">
      <div>
        <Link href="/" className="text-jbv-blue hover:opacity-80 transition-opacity">
          <span className="font-serif text-xl">Jeffrey Bazar</span>
        </Link>
      </div>
      <div className="flex items-center space-x-6">
        <Link href="/about" className="text-jbv-blue hover:opacity-80 transition-opacity">
          About
        </Link>
        <button className="border border-jbv-blue text-jbv-blue px-4 py-2 rounded hover:bg-jbv-blue hover:text-white transition-colors">
          Log In
        </button>
      </div>
    </nav>
  );
}
